package com.bham.pij.assignments.rps;

import java.util.ArrayList;

/**
 * @author iankenny
 */

import java.util.Random;
import java.util.Scanner;

public class FalloutTerminal {

	/**
	 * This method creates a single line of the terminal display.
	 * @param startAddress The first address of the line.
	 * @param wordProbability If less than or equal to 0.6 the line should contain one word.
	 * @return The line for display.
	 */
	public String buildDisplayLine(int startAddress, float wordProbability) {

		/*
		 *  Add your code here. When you have selected a random word
		 *  to add to the display, you must call addSelectedWord() to 
		 *  save that word. For example, if your variable holding the word is
		 *  called `word' you would call as follows:
		 * 	addSelectedWord(word);
		 * 
		 */ 
		
//		 position holds the random position of the word within the string
//		 the 30 character string that will contain a word is assigned to the
//		 wordSection variable
//		 The 30 character section that will contain the 30 character string of random
//		 characters is assigned to the ASCIISection variable
//		 display line is the string that will be returned from the method
//		 second address holds the memory address at the start of the second half of the line
//		 if the probability for a word to be in a line is met then the word is added to the 
//		 list of words to be considered to be a password
//		 If word probability is less than 0.6
//		 then there is a 50 percent chance that a string including a word will be added to either sides of the line 
//		 if not then a line of ASCII characters is set as the displayLine. 
		
		
		
		String displayLine = 0 + "x" + Integer.toHexString(startAddress).toUpperCase()+ " ";
		String secondAddress = Integer.toHexString(startAddress + NUM_CHARACTERS_PER_ROW * BYTE_SIZE/2).toUpperCase();
		if (wordProbability <= WORD_PROB_1)
		{
			String wordToAdd = getRandomWord();
			addSelectedWord(wordToAdd);	
			int position = getRandomPosition();
			String ASCIISection = getASCIILine();
			String wordSection = getWordSection(position, wordToAdd);
			
			if ((rand.nextInt(2)) == 0) 
			{				
				displayLine += wordSection + " " + 0 + "x"
						+ secondAddress + " " +  ASCIISection;
			}
			else
			{
				displayLine += ASCIISection + " " + 0 + "x" + secondAddress 
				+ " " + wordSection;
			}	
		}
		else
		{
			String ASCIIHalf1 = getASCIILine();
			String ASCIIHalf2 = getASCIILine();
			displayLine += ASCIIHalf1 + " " + 0 + "x" + secondAddress 
			+ " " + ASCIIHalf2;
		}
		
		return displayLine;
		
	}
	
	/**
	 * 
	 * @return random number between 1 and 23
	 */
	
	public int getRandomPosition()
	{
		return rand.nextInt(23) + 1;
	}
	
	
	/**
	 * 
	 * @return a random non alphanumeric, whitespace character by selecting a random number between 33 and 65 and then assigning the correct
	 * 		   ascii code to convert via a series of decisions  
	 */
	public char getRandomASCII()
	{
		char randomASCII;
		int randInt;
		randInt = rand.nextInt(32) + 33;
		if (randInt <= 47)
		{
			randomASCII = (char)(randInt);
		}
		else if (randInt <=54)
		{
			randomASCII = (char)(randInt + 10);
		}
		else if (randInt <=60)
		{
			randomASCII = (char)(randInt + 36);
		}
		else
		{
			randomASCII = (char)(randInt + 62);	
		}
		
		return randomASCII;
	}

	/** 
	 * @return a concatenated string of 30 random ascii characters
	 */
	public String getASCIILine()
	{
		String ASCIILine = "";
		for (int i = 0; i <30; i++)
		{
			ASCIILine += getRandomASCII();
		}
		return ASCIILine;
	}
	/**
	 * 
	 * @param position
	 * @param wordToAdd
	 * @return if the position to start the word is less than the index, or the index is greater the start position plus the length of the word
	 *         that index of the string is set to a random ascii character
	 *         otherwise the word is concatenated onto the string and that whole string is returned
	 */
	public String getWordSection(int position, String wordToAdd)
	{
		
		boolean added = false;
		
		String wordSection = "";
		for (int i = 1; i<=30; i++)
		{
			if ((position > i) || (i >= position + WORD_LENGTH))
			{
				wordSection += getRandomASCII();
			}
			else if (added == false)
			{
				wordSection += wordToAdd.toUpperCase();
				added = true;
			}
		}
		
		return wordSection;
	}
/*
 ***************************************************************************************	
 */

	private static final int START_ADDRESS = 0x9380;
	private static final int DISPLAY_HEIGHT = 20;
	private static final int NUM_CHARACTERS_PER_ROW = 60;
	private static final float WORD_PROB_1 = 0.6f;
	private static final int WORD_LENGTH = 8;
	private static final int NUM_GUESSES_ALLOWED = 4;
	private static final int BYTE_SIZE = 8;
	private static Random rand;
	private static final String[] words = {
			"flourish",
			"appendix",
			"separate",
			"unlawful",
			"platform",
			"shoulder",
			"marriage",
			"attitude",
			"reliable",
			"contempt",
			"prestige",
			"evaluate",
			"division",
			"birthday",
			"orthodox",
			"appetite",
			"perceive",
			"pleasant",
			"surprise",
			"elephant",
			"incident",
			"medieval",
			"absolute",
			"dominate",
			"designer",
			"misplace",
			"possible",
			"graduate",
			"solution",
			"governor"
	};
	
	private static String password;

	private static ArrayList<String> selectedWords = new ArrayList<String>();
	
	private void run() {
		
		System.out.println(buildDisplay());
		
		Scanner in = new Scanner(System.in);
		
		int guessCount = NUM_GUESSES_ALLOWED;
		
		boolean done = false;
		
		do {
			System.out.println("> Password required.");
			System.out.println("> Attempts remaining = " + guessCount);
			System.out.println(">");
			String guess = in.nextLine();
			
			if (guess.equalsIgnoreCase(getPassword())) {
				System.out.println("> Access granted.");
				done = true;
			}
			
			else {
				--guessCount;
				System.out.println("> Access denied.");
				System.out.println("> Likeness = " + getCorrectCount(guess, password));
			}	
		} while (guessCount > 0 && !done);
		
		if (guessCount == 0) {
			System.out.println("> Initiating lockout");
		}
		
		in.close();
	}
	
	private int getCorrectCount(String guess, String password) {
		
		int count = 0;
		
		for (int i = 0; i < guess.length(); i++) {			
			if (guess.charAt(i) == password.charAt(i)) {
				count++;
			}
		}
		
		return count;
	}
		
	private String getRandomWord() {
		return words[rand.nextInt(words.length)];
	}
	
	private String buildDisplay() {
		
		String ret = "";
		
		int address = START_ADDRESS;
						
		for (int i = 0; i < DISPLAY_HEIGHT; i++) {
											
			float rf = rand.nextFloat();
			
			String line = buildDisplayLine(address, rf);

			ret += line + "\n";
			
			address += BYTE_SIZE * NUM_CHARACTERS_PER_ROW;
		}
		
		setRandomPassword();
		
		return ret;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String pw) {
		password = pw;
	}

	private void addSelectedWord(String word) {
		selectedWords.add(word);
	}
	
	public void setRandomPassword() {
		password = selectedWords.get(rand.nextInt(selectedWords.size())).toLowerCase();
	}

	public FalloutTerminal() {
		rand = new Random(System.currentTimeMillis());	
	}
	
	public static void main(String[] args) {
		new FalloutTerminal().run();
	}
}
