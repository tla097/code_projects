//Thomas Armstrong
//2179997

package com.bham.fsd.assignments.jabberserver;

import javax.management.Query;
import javax.xml.transform.Result;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class JabberServer
{

    private static String dbcommand = "jdbc:postgresql://127.0.0.1:5432/postgres";
    private static String db = "postgres";
    private static String pw = "";

    private static Connection conn;

    public static Connection getConnection()
    {
        return conn;
    }

    public static void main(String[] args)
    {

        JabberServer jabber = new JabberServer();
        JabberServer.connectToDatabase();
        jabber.resetDatabase();
//
//
//         * Put calls to your methods here to test them.
//
//
    }

    public ArrayList<String> getFollowerUserIDs(int userid)
    {

        String query = "SELECT userida FROM follows WHERE useridb = ?";
        ArrayList<String> resultArray = new ArrayList<>();
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userid);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next())
            {
                resultArray.add(resultSet.getString(1));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return resultArray;
    }

    public ArrayList<String> getFollowingUserIDs(int userid)
    {
        String query = "SELECT useridb FROM follows WHERE userida = ?";
        ArrayList<String> resultArray = new ArrayList<>();
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userid);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next())
            {
                resultArray.add(resultSet.getString(1));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return resultArray;
    }

    public ArrayList<ArrayList<String>> getMutualFollowUserIDs()
    {
        String query = "SELECT f1.userida, f1.useridb " +
                "FROM (SELECT * FROM follows) AS f1 " +
                "INNER JOIN " +
                "(SELECT * FROM FOLLOWS) AS f2 " +
                "ON f1.userida = f2.useridb AND f1.useridb = f2.userida " +
                "WHERE f1.userida < f1.useridb " +
                "ORDER BY F1.userida";
        ArrayList<ArrayList<String>> resultArray = new ArrayList<>();
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next())
            {
                ArrayList<String> temporaryArray = new ArrayList<>();
                temporaryArray.add(resultSet.getString(1));
                temporaryArray.add(resultSet.getString(2));
                resultArray.add(temporaryArray);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return resultArray;
    }

    public ArrayList<ArrayList<String>> getLikesOfUser(int userid)
    {

        String query = "SELECT username, jabtext FROM jabberuser " +
                "NATURAL JOIN jab " +
                "WHERE jabid IN (SELECT jabid FROM likes WHERE userid = ?)";
        ArrayList<ArrayList<String>> resultArray = new ArrayList<>();
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userid);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next())
            {
                ArrayList<String> temporaryArray = new ArrayList<>();
                temporaryArray.add(resultSet.getString(1));
                temporaryArray.add(resultSet.getString((2)));
                resultArray.add(temporaryArray);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return resultArray;
    }

    public ArrayList<ArrayList<String>> getTimelineOfUser(int userid)
    {
        String query = "SELECT username, jabtext FROM jabberuser NATURAL JOIN jab WHERE userid IN (SELECT useridb " +
                "FROM follows WHERE userida = ?)";
        ArrayList<ArrayList<String>> resultArray = new ArrayList<>();
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userid);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next())
            {
                ArrayList<String> temporaryArray = new ArrayList<>();
                temporaryArray.add(resultSet.getString(1));
                temporaryArray.add(resultSet.getString((2)));
                resultArray.add(temporaryArray);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        return resultArray;
    }

    public void addJab(String username, String jabtext)
    {
        int jabId  = generateNextId("jabid");
        int userid = getUserid(username);
        String query = "INSERT INTO jab VALUES(?, ?, ?)";
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, jabId);
            statement.setInt(2, userid);
            statement.setString(3, jabtext);
            statement.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public int getUserid(String username)
    {
        String query = "SELECT userid FROM jabberuser WHERE username = ?";
        int userid = 0;
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next())
            {
                userid = resultSet.getInt(1);
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }

        return userid;
    }




    public int generateNextId(String idName)
    {
        String tableName;
        if (idName.equals("userid"))
        {
            tableName = "jabberuser";
        }
        else
        {
            tableName = "jab";
        }

        int nextID = 0;
        String query = "SELECT MAX( " + idName + ") FROM " + tableName;
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next())
            {
                nextID = resultSet.getInt(1);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return ++nextID;
    }

    public void addUser(String username, String emailadd)
    {
        int userid  = generateNextId("userid");
        String query = "INSERT INTO jabberuser VALUES(?, ?, ?)";
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userid);
            statement.setString(2, username);
            statement.setString(3, emailadd);
            statement.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void addFollower(int userida, int useridb)
    {
        String query = "INSERT INTO follows VALUES(?, ?)";
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userida);
            statement.setInt(2, useridb);
            statement.executeUpdate();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }

    public void addLike(int userid, int jabid)
    {
        String query = "INSERT INTO likes VALUES(?, ?)";
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, userid);
            statement.setInt(2, jabid);
            statement.executeUpdate();
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
    }

    public ArrayList<String> getUsersWithMostFollowers()
    {
        String query = " SELECT useridb " +
                "FROM follows " +
                "GROUP BY useridb " +
                "HAVING count(userida) >= ALL " +
                "(select count(userida) FROM follows GROUP BY useridb ORDER BY count(useridb) desc)";
        ArrayList<String> resultArray = new ArrayList<>();
        try
        {
            PreparedStatement statement = conn.prepareStatement(query);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next())
            {
                resultArray.add(resultSet.getString(1));
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        return resultArray;


    }

    public JabberServer()
    {
    }

    public static void connectToDatabase()
    {

        try
        {
            conn = DriverManager.getConnection(dbcommand, db, pw);

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /*
     * Utility method to print an ArrayList of ArrayList<String>s to the console.
     */
    private static void print2(ArrayList<ArrayList<String>> list)
    {

        for (ArrayList<String> s : list)
        {
            print1(s);
            System.out.println();
        }
    }

    /*
     * Utility method to print an ArrayList to the console.
     */
    private static void print1(ArrayList<String> list)
    {

        for (String s : list)
        {
            System.out.print(s + " ");
        }
    }

    public void resetDatabase()
    {

        dropTables();

        ArrayList<String> defs = loadSQL("jabberdef");

        ArrayList<String> data = loadSQL("jabberdata");

        executeSQLUpdates(defs);
        executeSQLUpdates(data);
    }

    private void executeSQLUpdates(ArrayList<String> commands)
    {

        for (String query : commands)
        {

            try (PreparedStatement stmt = conn.prepareStatement(query))
            {
                stmt.executeUpdate();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }

    private ArrayList<String> loadSQL(String sqlfile)
    {

        ArrayList<String> commands = new ArrayList<String>();

        try
        {
            BufferedReader reader = new BufferedReader(new FileReader(sqlfile + ".sql"));

            String command = "";

            String line = "";

            while ((line = reader.readLine()) != null)
            {

                if (line.contains(";"))
                {
                    command += line;
                    command = command.trim();
                    commands.add(command);
                    command = "";
                } else
                {
                    line = line.trim();
                    command += line + " ";
                }
            }

            reader.close();

        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return commands;

    }

    private void dropTables()
    {

        String[] commands = {
                "drop table jabberuser cascade;",
                "drop table jab cascade;",
                "drop table follows cascade;",
                "drop table likes cascade;"};

        for (String query : commands)
        {

            try (PreparedStatement stmt = conn.prepareStatement(query))
            {
                stmt.executeUpdate();
            }
            catch (SQLException e)
            {
                e.printStackTrace();
            }
        }
    }
}
