package com.bham.fsd.assignments.jabberserver;

import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;


/**
 * @author Thomas Armstrong
 * class for the currecnt user of the client
 */
public class Client
{
    private Socket clientSocket;

    private String username;

    /**
     * Constructor for the class. Creates and sets the client socket
     * sets the client username attribute
     * @param username username of the current user
     * @throws IOException
     */
    public Client(String username) throws IOException
    {
        this.clientSocket = new Socket("localhost", 44444);
        this.username = username;
    }

    /**
     * This method requests to users not followed from the database
     * @return the users not followed
     */
    public ArrayList<ArrayList<String>> requestToFollow()
    {
        JabberMessage jab = new JabberMessage("users");
        sendToServer(jab);
        JabberMessage response = receiveFromServer();
        return response.getData();
    }

    /**
     * This method requests to users timeline from the database
     * @return the timeline
     */
    public ArrayList<ArrayList<String>> requestTimeLine()
    {
        JabberMessage jab = new JabberMessage("timeline");
        sendToServer(jab);
        JabberMessage response = receiveFromServer();
        return response.getData();
    }

    /**
     * This method takes the data retrieved from the server and converts it into a format that will be shown on the
     * timeline
     * @param timeline the 2d array timeline data
     * @return the converted 1 dimensional array
     */
    public ArrayList<String> convertTimelineArray(ArrayList<ArrayList<String>> timeline)
    {
        String username, jab, likes;
       ArrayList<String> newTimeline = new ArrayList<>();
       for(ArrayList<String> array : timeline)
       {
           username = array.get(0);
           jab = array.get(1);
           likes = array.get(3);
           newTimeline.add(username + ": " + jab + "    (likes: "+ likes + ")");
       }
       return newTimeline;
    }

    /**
     * This method takes the data retrieved from the server and converts it into a format that will be shown on the
     * users to follow listview
     * @param toFollow the 2d array follower data retrieved from the server
     * @return the converted 1 dimensional array.
     */
    public ArrayList<String> convertFollowerArray(ArrayList<ArrayList<String>> toFollow)
    {
        ArrayList<String> newToFollow = new ArrayList<>();
        for(ArrayList<String> array : toFollow)
        {
            for (String element : array)
            {
                newToFollow.add(element);
            }
        }

        return newToFollow;
    }

    /**
     * This method sends a jab to the server
     * @param jab jab to be sent
     */
    public void sendToServer(JabberMessage jab)
    {
        try
        {
            ObjectOutputStream oos = new ObjectOutputStream(getClientSocket().getOutputStream());
            oos.writeObject(jab);
            oos.flush();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This method receives a message from the server
     * @return the received jab
     */
    public JabberMessage receiveFromServer()
    {
        JabberMessage response = null;
        try
        {
            ObjectInputStream ois = new ObjectInputStream(getClientSocket().getInputStream());
            response = (JabberMessage)ois.readObject();
        }
        catch (IOException | ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return response;
    }

    /**
     * This method sends a request to to a jab to the server. If granted the method returns true so that the
     * controller can update the timeline.
     * @param jabField the text to the posted
     */
    public boolean postJab(TextField jabField)
    {
        sendToServer(new JabberMessage("post " + jabField.getText()));
        JabberMessage response = receiveFromServer();
        if (response.getMessage().equals("posted"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * getters and setters for the attributes
     */
    public Socket getClientSocket()
    {
        return clientSocket;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername(String username)
    {
        this.username = username;
    }
}
