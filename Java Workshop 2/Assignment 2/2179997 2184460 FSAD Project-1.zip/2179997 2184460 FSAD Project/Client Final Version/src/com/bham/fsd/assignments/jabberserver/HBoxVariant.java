package com.bham.fsd.assignments.jabberserver;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

/**
 * @author Thomas Armstrong
 * This class is a Hbox that contains a label and a button for the purposes of generating buttons dynacially for each
 * jab
 */
public class HBoxVariant extends HBox
{

    @FXML private Button button = new Button();
    @FXML private Label label = new Label();

    private String id;
    boolean liked;

    /**
     * Constructor for the HBoxVariant Class. This sets the attributes of the class. Sets the label text, aligns the
     * label and button so the button and label is in the right position adds the buttons and label to the Hbox.
     * Depending on the picture, the image of the button will be set.
     * @param labelCaption
     * @param id The jab ID of the jab in the label caption. If this is not applicable then the ID is set to "0"
     * @param picture states whether the picture on the button will be one corresponding to a like or a follow
     */
    public HBoxVariant(String labelCaption, String id, String picture)
    {
        super();
        setID(id);
        setLiked(false);

        getLabel().setText(labelCaption);

        //moves button to the edge
        HBox.setHgrow(getLabel(), Priority.ALWAYS);
        getLabel().setMaxWidth(Double.MAX_VALUE);

        this.getChildren().addAll(getLabel(), getButton());

        Image img = null;
        if (picture.equals("like"))
        {
            img = new Image("/haroldthumbsup2.png");
        }
        else
        {
            img = new Image("/haroldfollow.png");
        }

        getButton().setPrefHeight(80);
        ImageView pic = new ImageView(img);
        pic.setFitHeight(80);
        pic.setPreserveRatio(true);

        getButton().setGraphic(pic);
    }


    /**
     * getters and setters for the attributes
     */
    public Label getLabel()
    {
        return label;
    }

    public String getID()
    {
        return this.id;
    }

    public void setID(String id)
    {
        this.id = id;
    }

    public Button getButton()
    {
        return button;
    }

    public boolean beenLiked()
    {
        return liked;
    }

    public void setLiked(boolean liked)
    {
        this.liked = liked;
    }

    /**
     * Sets the like status of the jab to true.
     */
    public void like()
    {
        setLiked(true);
    }







}

