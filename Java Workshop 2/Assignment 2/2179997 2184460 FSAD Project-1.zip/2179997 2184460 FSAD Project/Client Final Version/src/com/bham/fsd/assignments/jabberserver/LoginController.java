package com.bham.fsd.assignments.jabberserver;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

/**
 *
 * @author Thomas Armstrong
 * Login Contoller Class
 *
 */

public class LoginController implements Initializable
{

    @FXML private TextField T1;

    private Client client;

    /**
     * Getter and and setter for the client attribute
     */
    public void setClient(Client client)
    {
        this.client = client;
    }
    public Client getClient()
    {
        return this.client;
    }

    /**
     * This method instantiates a new client object
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        try
        {
            setClient(new Client(T1.getText()));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * This method is what happens when the user presses the register button. The username of the client is set to be
     * the text in the username text field and a request to register  that username to the server is sent. Finally an
     * attempt to login is made
     */
    public void register(ActionEvent event) throws IOException
    {
        getClient().setUsername(T1.getText());

        //sending to server
        getClient().sendToServer(new JabberMessage("register " + getClient().getUsername()));

        //receiving from server
        JabberMessage response = getClient().receiveFromServer();

        //attempts login and then takes the next steps
        attemptLogin(event, response);
    }

    /**
     * This method is what happens when the user presses the sign in button. The username of the client is set to be
     * the text in the username text field and a request to sign in that username to the server is sent.
     * Finally attempt to login is made.
     */
    public void SignIn(ActionEvent event) throws IOException
    {

        getClient().setUsername(T1.getText());
        //sets username to be the text field
        JabberMessage jm = new JabberMessage("signin " + getClient().getUsername());

        //sending to server
        getClient().sendToServer(jm);

        //receiving from server
        JabberMessage response = getClient().receiveFromServer();

        //attempts login and then takes the next steps
        attemptLogin(event, response);
    }

    /**
     * This method verifies login with the response from the server. If valid the next window opens, else an error
     * message is shown
     * @param response Response of the server replying to the login request.
     */
    public void attemptLogin(ActionEvent event, JabberMessage response)
    {
        if (validUsername(response))
        {
            //opens a the next window
            openNewWindow(event);
        }
        else if (inValidUserName(response))
        {
            //opens error window
            newErrorWindow();
        }
        else
        {
            System.out.println("Protocol breached");
        }
    }

    /**
     * This method opens an error window if the user enters incorrect login information.
     */
    private void newErrorWindow()
    {
        Alert E1 = new Alert(Alert.AlertType.ERROR);
        E1.setTitle("Username Incorrect");
        E1.setContentText("Please retype your username");
        E1.showAndWait();
    }

    /**
     * This method verifies if the username is a valid.
     * @param jab the response from the server
     * @return true if the username is correct.
     */
    public boolean validUsername(JabberMessage jab)
    {
        return (jab.getMessage().equals("signedin"));
    }

    /**
     * This method verifies if the username is inValid.
     * @param jab the response from the server
     * @return false if the username is incorrect.
     */
    public boolean inValidUserName(JabberMessage jab)
    {
        return (jab.getMessage().equals("unknown-user"));
    }

    /**
     * Opens the window allowing access to the like and follow functionality.
     * @param event the Action event passed in through the Sign in or register button. This is so the old window can
     *              be closed
     */
    public void openNewWindow(ActionEvent event)
    {
        try
        {
            //hides the current window
            ((Node)event.getSource()).getScene().getWindow().hide();

            //opens a new menu
            Stage stage = new Stage();
            FXMLLoader loader = new FXMLLoader();

            Pane root = loader.load(getClass().getResource("Main.fxml").openStream());
            RefresherThread rT = new RefresherThread(loader, getClient());

            Scene scene = new Scene(root, 1200, 600);
            stage.setScene(scene);
            stage.setTitle(getClient().getUsername() + " has successfully logged in");
            stage.show();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }


}
