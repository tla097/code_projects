package com.bham.fsd.assignments.jabberserver;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.util.ArrayList;


/**
 *
 * @author Thomas Armstrong
 * Main Contoller Class
 *
 */
public class MainController
{
    @FXML
    private Button B3 = new Button();

    @FXML
    ListView<HBoxVariant> lvTimeline = new ListView<>();
    @FXML
    ListView<HBoxVariant> lvFollowers = new ListView<>();

    @FXML
    TextField T2 = new TextField();

    private Client client;


    /**
     * This method initialises the the GUI for the Main scene - ie sets the timeline and jabberusers to follow.
     * The client is also passed into this method to access the socket connection and the client methods.
     * @param client the Client object
     * @return a list of 'mutual' follows, i.e. users who follow each other.
     */
    public void  initialiseData(Client client)
    {
        this.client = client;

        ArrayList<ArrayList<String>> timeline2d = client.requestTimeLine();

        ArrayList<String> timeline = client.convertTimelineArray(timeline2d);

        ArrayList<HBoxVariant> hBoxVariantList = setHBoxVariantListLikes(timeline, timeline2d);

        ObservableList<HBoxVariant> HBoxVariantObservableList = setObservableHBoxList(hBoxVariantList);

        //sets up display for list view
        lvTimeline.setItems(HBoxVariantObservableList);

        lvTimeline.setEditable(true);

        setLikeButtons(timeline2d, hBoxVariantList);

        updateFollowers();

    }

    /**
     * This method takes the timeline and creates an array list consisting of HBox Variants
     * @param timeline
     * @return the hBoxVariant List
     */
    public ArrayList<HBoxVariant> setHBoxVariantListFollows(ArrayList<String> timeline)
    {
        ArrayList<HBoxVariant> hBoxVariantList = new ArrayList<>();
        for (int i = 0; i < timeline.size(); i++)
        {
            hBoxVariantList.add(new HBoxVariant(timeline.get(i), "", "follow"));
        }
        return hBoxVariantList;
    }

    /**
     * This method initialises the action events for all the generated like buttons
     * @param timeline2d timeline returned from the server as the JabberMessage Data
     * @param hBoxVariantList the list of HBoxVariants
     */
    public void setLikeButtons(ArrayList<ArrayList<String>> timeline2d, ArrayList<HBoxVariant> hBoxVariantList)
    {
        for (int i = 0; i < hBoxVariantList.size(); i++)
        {
            hBoxVariantList.get(i).setID(timeline2d.get(i).get(2));
            int finalI = i;
            hBoxVariantList.get(i).getButton().setOnAction(e -> like(hBoxVariantList.get(finalI)));
        }
    }

    /**
     * This method initialises the action events for the generated follow buttons.
     * @param hBoxVariantList the list of HBoxVariants
     */
    public void setFollowButtons(ArrayList<HBoxVariant> hBoxVariantList)
    {
        for (int i = 0; i < hBoxVariantList.size(); i++)
        {
            hBoxVariantList.get(i).setID("0");
            int finalI = i;
            hBoxVariantList.get(i).getButton().setOnAction(e -> follow(hBoxVariantList.get(finalI)));
        }
    }

    /**
     * This method is what happens when you click on a follow button.
     * The client requests to follow a user from the server. If successful the user to follow and the timeline is
     * updated
     * @param cell the HBox Variant containing the particular button being pressed
     */
    public void follow(HBoxVariant cell)
    {
        client.sendToServer(new JabberMessage("follow " + cell.getLabel().getText()));
        JabberMessage response = client.receiveFromServer();
        if (response.getMessage().equals("posted"))
        {
            updateFollowers();
            updateTimeline();
        }
    }

    /**
     * This method requests the follower data from the server and then converts that data into an observable
     * arraylist of HBoxVariants appropriate for the addition to a listview.
     * The buttons of the HBoxVariants are set and then the listview is then cleared and refreshed with the updated
     * list.
     */
    public void updateFollowers()
    {
        Platform.runLater(new Runnable()
        {
            @Override
            public void run()
            {
                ArrayList<ArrayList<String>> toFollow2d = client.requestToFollow();
                ArrayList<String> toFollow = client.convertFollowerArray(toFollow2d);
                ArrayList<HBoxVariant> hBoxVariantList = setHBoxVariantListFollows(toFollow);
                ObservableList<HBoxVariant> observableHBoxList = setObservableHBoxList(hBoxVariantList);
                setFollowButtons(hBoxVariantList);
                lvFollowers.getItems().clear();
                lvFollowers.setItems(observableHBoxList);
            }
        });
    }

    /**
     * This method requests the timeline data from the server and then converts that data into an observable
     * arraylist of HBoxVariants appropriate for the addition to a listview.
     * The buttons of the HBoxVariants are set and then the listview is then cleared and refreshed with the updated
     * list.
     */
    public void updateTimeline()
    {

        Platform.runLater(new Runnable()
        {
            @Override
            public void run()
            {
                ArrayList<ArrayList<String>> timeline2d = client.requestTimeLine();
                ArrayList<String> timeline = client.convertTimelineArray(timeline2d);
                ArrayList<HBoxVariant> hBoxVariantList = setHBoxVariantListLikes(timeline,timeline2d);
                ObservableList<HBoxVariant> observableHBoxList = setObservableHBoxList(hBoxVariantList);
                setLikeButtons(timeline2d, hBoxVariantList);
                lvTimeline.getItems().clear();
                lvTimeline.setItems(observableHBoxList);
            }
        });
    }

    /**
     * This method sets the HBoxVariant List for the like listview. Using the timeline and the timeline 2d the list
     * is initialised with the newly created HBoxVariants
     * @param timeline array containing just the jabs for every user on the clients timeline
     * @param timeline2d array containing all the timeline data retrieved by the server
     * @return the HBoxVariantList
     */
    public ArrayList<HBoxVariant> setHBoxVariantListLikes(ArrayList<String> timeline, ArrayList<ArrayList<String>> timeline2d)
    {
        ArrayList<HBoxVariant> hBoxVariantList = new ArrayList<>();
        for (int i = 0; i < timeline.size(); i++)
        {
            hBoxVariantList.add(new HBoxVariant(timeline.get(i), timeline2d.get(i).get(2), "like"));
        }
        return hBoxVariantList;
    }

    /**
     * This method takes the array of HBoxVariants and converts that into an observable list
     * @param hBoxVariantList array of HBoxVariants
     * @return the created observable list
     */
    public ObservableList<HBoxVariant> setObservableHBoxList(ArrayList<HBoxVariant> hBoxVariantList)
    {
        ObservableList<HBoxVariant> observableHBoxList = FXCollections.observableArrayList(hBoxVariantList);
        return observableHBoxList;
    }

    /**
     * This method is what happens when the sign out button is pressed. A signout message is sent to the server and
     * then the socket is closed, the window is closed and finally the application is closed.
     */

    public void signOut(ActionEvent event) throws IOException
    {
        //closes the connection
        JabberMessage jab = new JabberMessage(("signout"));
        client.sendToServer(jab);
        client.getClientSocket().close();

        //hides the current window
        ((Node)event.getSource()).getScene().getWindow().hide();

        //exits the application
        System.exit(1);
    }

    /**
     * This method is what happens when a like button is pressed. If the jab has not been liked before, then a
     * request to like the jab is sent to the server. If this is successful then the liked status of the jab is
     * updated and the timeline is then updated.
     * @param cell the particular HBoxVariant that contains the button that has been pressed.
     */
    public void like(HBoxVariant cell)
    {
        if (!cell.beenLiked())
        {
            client.sendToServer(new JabberMessage("like " + cell.getID()));
            JabberMessage response = client.receiveFromServer();
            if (response.getMessage().equals("posted"))
            {
                cell.like();
                updateTimeline();
            }
        }

    }

    /**
     * This method posts a jab and then updates the timeline.
     */
    public void postJab(ActionEvent event)
    {
        if(client.postJab(T2))
        {
            updateTimeline();
        }
    }


}
