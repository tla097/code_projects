package com.bham.fsd.assignments.jabberserver;

import javafx.fxml.FXMLLoader;

/**
 *
 * @author Thomas Armstrong
 * Refresher Thread Class
 *
 */

public class RefresherThread implements Runnable
{

    private FXMLLoader loader;
    private Client client;

    /**
     * Starts the thread and sets the loader and client attributes of the class
     * @param loader loader of the main controller
     * @param client
     */
    public RefresherThread(FXMLLoader loader, Client client)
    {
        this.loader = loader;
        this.client = client;
        new Thread(this).start();
    }

    /**
     * The thread updates the timeline and users to follower of the client every 1.5 seconds so that if a user that
     * the current user follows is online posts a jab then the user's timeline and users to follow will update
     * automatically. Likewise if that that user likes a jab from a user that the current user the likes on the
     * timeline will update automatically.
     */
    @Override
    public void run()
    {
        MainController mainController = (MainController)loader.getController();
        mainController.initialiseData(client);
        Boolean running = true;
        while (running)
        {
            try
            {
                Thread.sleep(1500);
                mainController.updateTimeline();
                mainController.updateFollowers();
            }
            catch (InterruptedException e)
            {
                running = false;
            }
        }
    }


}
