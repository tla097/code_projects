package com.bham.fsd.assignments.jabberserver;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

/**
 *
 * @author Alexander Parker
 * The ClientConnection class.
 */

public class ClientConnection implements Runnable {

    private final Socket socket;
    private final JabberDatabase data;
    private int userID;
    private String userName;

    public ClientConnection(Socket clientSocket, JabberDatabase jabberDatabase) {
        this.socket = clientSocket;
        this.data = jabberDatabase;
        this.userID = -1;                       //Set to an invalid value. The real value will be taken from the database.
        this.userName = "-1";                   //Set to an invalid name. The real name will be taken from the database.
        new Thread(this).start();         //Starts the client connection in a Thread to allow multiple users to connect at once.
    }

    public void run() {
        Boolean running = true;
        while (running) {
            try {
                Thread.sleep(100);
                ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());         //Waits to receive a request from the server.
                JabberMessage request = (JabberMessage) ois.readObject();
                JabberMessage reply = handleRequest(request);
                if (reply.getMessage().equals("SIGNOUT")) {         //This ends the client connection thread if the client signs out.
                    running = false;
                }
                else {
                    ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());          //Sends JabberMessages back to the client.
                    oos.writeObject(reply);
                    oos.flush();
                }
            } catch (IOException | ClassNotFoundException | InterruptedException e) {
                running = false;            //This ends the client connection Thread if the client crashes or closes with the X button.
            }
        }
    }

    public JabberMessage handleRequest(JabberMessage request){          //This method interprets the requests and communicates with the database accordingly.
        String replyMessage;
        ArrayList<ArrayList<String>> replyData = new ArrayList<ArrayList<String>>();
        String rString = request.getMessage();
        String[] commands = rString.split(" ",2);           //Splits the request around the first space in the string.
        if (commands[0].equals("signin")) {         //P1
            int id = data.getUserID(commands[1]);
            if (id > -1) {                          //P1a
                userID = id;
                userName = commands[1];
                replyMessage = "signedin";
            }
            else {                                  //P1b
                replyMessage = "unknown-user";
            }
        }
        else {
            if (commands[0].equals("register")) {           //P2
                String email = commands[1]+"@gmail.com";
                data.addUser(commands[1],email);
                userName = commands[1];
                userID = data.getUserID(commands[1]);
                replyMessage = "signedin";
            }
            else {
                if (commands[0].equals("signout")) {            //P3
                    replyMessage = "SIGNOUT";
                }
                else {
                    if (commands[0].equals("timeline")) {           //P4
                        replyMessage = "timeline";
                        replyData = data.getTimelineOfUserEx(userID);
                    }
                    else {
                        if (commands[0].equals("users")) {          //P5
                            replyMessage = "users";
                            replyData = data.getUsersNotFollowed(userID);
                        }
                        else {
                            if (commands[0].equals("post")) {           //P6
                                replyMessage = "posted";
                                data.addJab(userName,commands[1]);
                            }
                            else {
                                if (commands[0].equals("like")) {             //P7
                                    replyMessage = "posted";
                                    data.addLike(userID, Integer.parseInt(commands[1]));
                                }
                                else {
                                    if (commands[0].equals("follow")) {         //P8
                                        replyMessage = "posted";
                                        data.addFollower(userID,commands[1]);
                                    }
                                    else {
                                        replyMessage = "The server didn't recognise that request";      //This is just a fail-safe, it should never happen if the client works properly.
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        JabberMessage jm = new JabberMessage(replyMessage, replyData);
        return jm;
    }
}