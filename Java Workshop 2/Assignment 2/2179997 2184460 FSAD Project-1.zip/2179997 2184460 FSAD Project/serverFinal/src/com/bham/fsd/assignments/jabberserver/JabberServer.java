package com.bham.fsd.assignments.jabberserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author Alexander Parker
 * The JabberServer class.
 */

public class JabberServer implements Runnable {

    private static final int PORT_NUMBER = 44444;
    private ServerSocket serverSocket;

    public JabberServer() throws IOException {
        serverSocket = new ServerSocket(PORT_NUMBER);
        serverSocket.setSoTimeout(  30000);         //Set to 30 seconds.
        new Thread(this).start();           //Starts the server in a thread so that the serverSocket.accept(); line doesn't prevent the rest of the program continuing.
    }

    public void run(){
        try {
            while (true) {
                Thread.sleep(100);
                Socket clientSocket = serverSocket.accept();            //Waits for a client to connect on the socket.
                ClientConnection client = new ClientConnection(clientSocket, new JabberDatabase());         //Creates a client connection thread, then continues to wait for new clients.
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}