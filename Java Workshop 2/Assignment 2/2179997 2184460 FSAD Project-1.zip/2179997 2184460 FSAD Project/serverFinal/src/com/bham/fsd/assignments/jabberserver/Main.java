package com.bham.fsd.assignments.jabberserver;

import java.io.IOException;

/**
 *
 * @author Alexander Parker
 * The Main class.
 */

public class Main{

    public static void main(String[] args) throws IOException {
        JabberServer myServer = new JabberServer();         //Starts the server thread.
    }
}
